# Solunera v2: website + HQ

**Website** (`/`, Arabic at `/ar`): live 3D S-01 face, work slider, services, story, contact form.
**HQ** (`/<HQ_PATH>/`): private. Nothing on the site links to it.

| HQ section | What it does |
|---|---|
| Home | Your tasks, next demo meetings, visit follow-ups, quotes waiting, website inquiries |
| Field visits | Sales team logs each visit from the phone: problems, what they use, interest, photos, next step |
| Demos | Board from Building to Won / Lost / No reply, with meeting dates and deal prices |
| Quotes | Arabic or English quote with packages, yearly price, payment stages, live A4 preview, print to PDF |
| Tasks | One board per project, drag cards between To do / Doing / Review / Done |
| People | Owner adds sales and dev accounts, edits the details printed on quotes |

Arabic + English everywhere. Zero dependencies, Node.js 18+.

```bash
node server.js     # real mode
npm run demo       # empty store gets example data
```

## Hosting (Render + Supabase, free)
1. Supabase: run `supabase.sql` (the same table as the old site works; v2 saves to its own row `hq-v2`, old data is untouched).
2. Push this folder to GitHub, create a Render Web Service (Docker, Free), add the variables from `.env.example`.
3. First sign-in uses `OWNER_EMAIL` / `OWNER_PASSWORD`, then you choose a new password.
4. UptimeRobot can ping `/api/ping` every 5 minutes to keep it awake.

## Editing the website
- Projects, services, story and all Arabic/English text: `public/site.js` (top of the file).
- Screenshots: `public/media/`.
- The face: `public/robot.js`.

Built by Solunera, Kamel Nassif · @soluneragency
